// Helper functions
export function formatDate(date) {
  // TODO: format date
}