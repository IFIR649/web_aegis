// Auth service
export function login() {
  // TODO: authentication logic
}