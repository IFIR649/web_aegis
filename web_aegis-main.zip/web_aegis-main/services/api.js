// API service
export function fetchData() {
  // TODO: fetch API data
}