// History page
export function History() {
  // TODO: Historical data logic
}