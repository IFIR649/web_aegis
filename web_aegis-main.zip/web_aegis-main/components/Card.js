// Card component
export function Card() {
  // TODO: Card logic
}