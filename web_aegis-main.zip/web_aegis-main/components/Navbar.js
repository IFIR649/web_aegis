// Navbar component
export function Navbar() {
  // TODO: Navbar logic
}